CREATE VIEW aggregate_prizes AS
WITH bind_strategy AS (
    SELECT p.id,s.name FROM players p INNER JOIN strategy_kinds s ON p.strategy=s.id
),
bind_prize AS (
    SELECT p.player_id,k.name,p.cnt,p.reward FROM prizes p INNER JOIN prize_kinds k ON p.prize_kind=k.id
),
bind AS (
    SELECT bs.id,bs.name as strategy,bp.name as prize_kind,bp.cnt,bp.reward
    FROM bind_strategy bs INNER JOIN bind_prize bp ON bs.id=bp.player_id
),
aggregate AS (
    SELECT id,sum(cnt) AS ttl_cnt,sum(reward) AS ttl_reward FROM bind GROUP BY id
)
SELECT a.id,b.name AS strategy,2100000 AS ttl_payed,a.ttl_cnt,a.ttl_reward FROM aggregate a INNER JOIN bind_strategy b ON a.id=b.id;

