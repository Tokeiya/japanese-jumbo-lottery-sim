CREATE MATERIALIZED VIEW data_source AS
WITH base AS (SELECT person.id,
                     person.process_unit,
                     person.strategy,
                     prizes.prize,
                     prizes.cnt,
                     prizes.reward
              FROM person
                       JOIN prizes ON person.id = prizes.person_id),
     aggregate AS (SELECT base.id,
                          SUM(base.reward) AS total_reward
                   FROM base
                   GROUP BY base.id)
SELECT a.id,
       p.process_unit,
       p.strategy,
       a.total_reward,
       p.total_payed
FROM aggregate a
         JOIN person p ON a.id = p.id
ORDER BY a.id;

ALTER MATERIALIZED VIEW data_source OWNER TO tokeiya3;

CREATE INDEX idx_data_source_id
    ON data_source (id);

CREATE INDEX idx_data_source_process_unit
    ON data_source (process_unit);

CREATE INDEX idx_data_source_strategy
    ON data_source (strategy);

CREATE INDEX idx_data_source_total_reward
    ON data_source (total_payed);

CREATE INDEX idx_data_source_total_payed
    ON data_source (total_payed);

